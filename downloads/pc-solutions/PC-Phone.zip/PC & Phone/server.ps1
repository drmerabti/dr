﻿# Local file server - share files between PC and phones via browser
# Double-click the .bat file to run it. Close the window to stop.

# --- Run as administrator ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$Port = 8080
$Root = Join-Path $PSScriptRoot 'Partage'
if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }

# --- Allow the port in Windows Firewall (once) ---
$ruleName = "Partage Local $Port"
if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Any | Out-Null
}

# --- Helpers ---
function Get-Query($req, $key) {
    $q = $req.Url.Query
    if (-not $q) { return $null }
    foreach ($p in $q.TrimStart('?').Split('&')) {
        $kv = $p.Split('=', 2)
        if ($kv.Count -eq 2 -and $kv[0] -eq $key) {
            return [Uri]::UnescapeDataString($kv[1].Replace('+', ' '))
        }
    }
    return $null
}

function Send-Text($res, [string]$text, [string]$type) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($text)
    $res.ContentType = $type
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
}

function Get-SafeName([string]$name) {
    if (-not $name) { return $null }
    $name = [IO.Path]::GetFileName($name)
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) { $name = $name.Replace([string]$c, '_') }
    if ($name.Trim() -eq '' -or $name -eq '.' -or $name -eq '..') { return $null }
    return $name
}

function Get-FreePath([string]$name) {
    $dest = Join-Path $Root $name
    if (-not (Test-Path -LiteralPath $dest)) { return $dest }
    $base = [IO.Path]::GetFileNameWithoutExtension($name)
    $ext  = [IO.Path]::GetExtension($name)
    $i = 1
    do { $dest = Join-Path $Root "$base ($i)$ext"; $i++ } while (Test-Path -LiteralPath $dest)
    return $dest
}

# --- Web page shown in the phone browser ---
$Html = @'
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>مشاركة الملفات</title>
<link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAqr0lEQVR42u19eZhdVZXvb+19hjvWXKlKJZWBzCkSwKCAQgKKPlAB2+5bH9AixqlbX6vYbTuhVq4jLc3jteKAogjSra/KT5FmUBEhMgkiU6gwZIBMlaokVan5Dufsvd4f55ybqkpVcqtyhwJ7f199N/nuveees9dv/daw19qb8CocbW1t4gFAzNnawh0drWrsewTg7677YY2m6NxRJ7Ms7cq5YVPMz2QzzUracRKIGuAYEdkESAAAk8vQaYdpiLVOSe32h0OhXUMZp6vKwL6sxPYaU3T/5yeuGJx4L4n2dnmgs5M2AxrJpH61zSW9moS+taWFOloTGiDOCeCGG2KpkcrlKa1PZfA6MK3QSi1jUJ0QFCHDAoNzD8rMYGaAecJMEIgEyP9g8C47WTBjSBB6IMQ2A7SVmZ+MWOLp0xba25OtrdkxNykSLS3U0dnJrxYwzG4AMFOio0N0JBIadEToF379luWaeH2W8RZoPoNBi2UoBIDAWkG7LqA1mHVO0uzJlCh4ZGaaAAAfEt7HyUcZgQQJARISJA2QEIDWUNm0C8I2SeIRknxfVNoP/fpTl+05CgytrXoMnv4HANPT9iP0/q5rblk1wninw3yR1vr1ph0OMQB2HGjlgplV8ETECFS5UM/HAJjBDBCDmYiEFIYBYZhg1tBOtp+IHrUl3W5L856xYEi0t8uJIP4fAEwl+K0tFNj1K6+/uarHsd+ZdTJXaNB6aYVCrBWUkwVrrTzFJfKfo9TP4oGCPeIQQkphWSAiqGymXwD3WkL8tCGt7r0luTGdA8IsMw80WwSf3NpC8AWfuO7WpYez/H5X898L014AMFQ24wmdPFqefezFzAx9BAw2wBpw3U5B/JNqg2/r+PTG7tnGCFTmOfNsvE/1F15z25qM1h9j5kuFbcdVNgvtOoGmz0KhHwcMBJKGJYRpQqczPYLwkxqJ73Z89srdOSCU2Uco24T6D68Cpy4L/KsG/l6YdtjNpMBaK5/eBV7dQzNrFtKU0rahM5k+SfSDuojxf39+1eU9AJBItMuJ4exrFgBtbW0iuWkTg4gT1/2wpt+xPu0ofFRadnyM4F9F2j4NUiAoIaQh7TB0JtNlCf3N5ZGB73/7E5/IJBLtsqO99GahpJO8oa3N2JxMugBw/tdvuUIBSWGFFrvp0deu4KcEgmFIywa7zhMWq6t/8/n3/W4iM752AMBM2LSJkEzqd3z5e8syVvRaLYxLtOtCK8f1MnL02hb8JEAggjbssNRag5X6wYtd+z7f9Z3P9zKzBKCpBGxQ9Ekfa9/e9rWbP+SQvEYYZo2THn2t2PhpD0EEBjCadeA6rg6ZkmpqaykisD3M2atu+fjld/kYEUSkX7UA2NB2v7E5eZ77rq9/u3ZYVH6LhXm5cjLQSikikvgrHFIQRjIOJAGnNM/B2csX4OTmBsyrqXBDkYgxMjKKqmjom9sM44snE2WZWRKRerUBgBLt7aKjtVVddM3NZ46wvJkMa6WTGlEECNBfGd0Hmi8Ig6MZvGFRIz705nU47aT5R0UMwUcBPABgIxG9wswGEbmvDgAwU9umTZRMJvVbv/LjK10pvwshI8rJuAQy8Fc6AuFf+oaV+OQ7zoaUEsyAZgaRLwgigBm+sA0AXQCuIKI/FIsJCiuQtjYBIk4C+vyv/fjL2gp/UWfSYNdVRKUVPvmTzgC09nwpIoLwIa81lyz7IoXAwGgaV5y1Cp94x3owAKUZUhDkRDL0/m8AUACaANzDzB8loh8Vwzk0Cif7NpFMJnVbW5vxoLXoRrbC73fSo4o8R6ak9l4KAUcpDI1mIQgImQakFMg4DrKuBhEhYpswBEFpLr7wUxlcuGYxPvGO9dCaQUSQ4rjkK32TYAK4iZmbiOgrzCzYYwkulKIUTvg33hh5+HDo52yEL3JSwy4VmmHy9K4HUxk0xMNYv2IBzlg6H/NqKmGZBvqHR7GrdwCPbd+Lx3fsw+FUFvGQBUEEzVyU+0k7Cgtr4rjpw5cgErIBnnbAyz4QJIDriOhTzCwAcCFAQAWQvkAyqf/l1lujz+zDL9m03+aMDrulpnwpCClHQYLx7nUrcNmbTkFjdcWUn9998DA6Hu/Er//yIhzNiFhGwdmAiJBxHHz7iguwbkkztGYIMaMpZ98kGAC+Q0T/VCgQnBgAmAlEuK69PXT3jvTtbNhvc1PlEL7AUDqD5qoYrn7XerzO966V9iuBfCfLX9QHkaedAPDsK1245r8fwvaDA4iHLCitCwbI/tEMWl+/Ep+5ZEPO5p/gCJzDG4joY55jiHEVUtNmqRPN7rXdf7+8Z2fq/8Esn/AHU2mc2jwH33v/RXjdSfOhtAazN+FCEASR7wB6tlcQgZmhNGPtoiZ8/wMX4YzFDRgYTUMKUQDNB7KuRmNFFB84dx2YAVGYeMvwQfBPT7708jeJSDGfWCJtxs7ZBsDYlUwqWrr+h2RHL3VS5aH94bSDUxbMwfXvuQDV8aivacdPNQSAUJoRtkycu2oROvd0Y1fvIEKmxIm4BFIIDKUy+NB5p+HM5QuhecbUPxVrq3Asds6u2hXZxFmn/HFDW5uxa/NmXTIABIs6b/3qj5MUil3lpEdKHuMTETKuwpx4CN+68u2oikWgZ0CzgQNomQbOWtaM+57bjqGMM2MmIAKySmFeVQyfvfgcWIbpxfmFy32R1qCwKfTuwcxbd1av2P7UN69+ZqYgEDMV/pu/9qP3aCv8JZUZLbm3n7NCWuNL79qAuooY1MwdrBwT1MSjuOqCM5B1XBBmei2BVNbBu1+/CvFI2E/0FDjfRkwAxAUtC3XjnLofXPLvt75xczLpJhLtsqgASCTa5eZk0r343245ncn6vutkNWtd8px+YPf//qwWrFvaXBAHSwqPCc47eSnOXNKE4Ux22oAiAFlXobEiirefuhyMgtn+ycJdWj2vDi3z6yI9I87PPnpDe2NHR6tGW5soDgCYqWN1J1/+je9WD7t8G4SIsnJR6rw+ESHluFhaV4mN567z7GuB7sCz+4TLzloLERSSTzPdm8o62LBiAWriUXAxtB9HMpmAEOctn68UGQu2D6duaWtro0RLy7QKZPMGQKKjQyCZ1N0qfAPZ4RXKSbt+AQdKDQDXVfiHt5w+JrFCBWIW7zrrlszDSXOqkHbVtK6tGbANgQtPXVaCpJf3es7KRbJCKNc1Qm97xFx0dUdrq0q0t4uCAiCoUnnb13+0kezQ5U5qpCwLO4IIoxkHp8yvw7ktS8CF9a59ITIsw8CpCxqQcdy82UWQp/0nz6tHS3OjH/pRURVBM9BUU4k1zfVyaHBAsWF+8cKv3fymjtZWlUgkZEEA0NbWJjpaW/Ul37h5kQPz31U2w+QtSqAc2q+0wqVnnQwhBIqRxg/Cv5Pnz5mWG0hEcJTC+S2L/Xsr/lKT35KAs5cvJOW4BCHMFPON77n21ujq1av5qO6nmQBga0sLEcCDLr5FplmjldLlWM8XRBjNOmhpqsP61SeBGYXIrE0axgHAkoZahC2Zd3rYURo10TDOWbV4HEWXwgycsawZ1bGwyKRTrgxHW7oz7peSyaROtHaIEwJAQP3nf+3mS8kOXeSmRstWyUNEyLouLjptOUzDKJqGBeFfU3UF6mIRuFofd/FGCELacXBK8xw0Vlf46WYqyZwwgHk1lVjWUI2Mo6ROp5SSxlXv+MZP1nV0tKq2NhYzAwAzdXR28iXX31zlMK5h5XK5KnkIQMZVmFcZw/lrluYYoTiT6r3GIyHMqYjCUfq4OQECoLTG+pULc35EqUawvHzG0vlwtSawBknDSrn6OmYmYNPMGCDw+odH+VMyFFmonIymMhVwBuHVm5Y3ozIazlXRFG1SfQE2Vcag8mAAR2nUxcI4Y2lzyeh/ImDXLWpCyJBgkFTplIId3nDBN265NJlM6kT71AkiMYXnJzpaE/qia29drFh+3M2kNUGUrXqXGbClwAVrl5bs9wCgqSYO1nzMsFoKQtpxsbqpHg1V8ZLR/1gzAADL5tZhfk0cWVeBBBErlzOak++59tZoRyKhvY73PAHQ5ucbR1Lu56Rtxz36L0/DhiAg5bhY3liDlgWNfnatNLdSGw3nwTQEpTTOWNJUcvoPzI9mRsgysWZ+vR+6klBOVks7vKzHUR8AESfaJ3cIxWRhXzKZ5Iv/7acrtJTvUZkUT5XwCVbUgj8qCsIFso6Lc1cuhCFlrr6vFLTaUBWDJJELtyYbSmvEbAuvXzJ/3HdLzZAAcNrCuUdgQUTKybKj9acS19xYORULTEXrPORkPyktO6y11mM50Ktn8zq4sq7CaNbBaNZBynHh+gsyhdRQpTXiIRPnrFxQ8gmujoZgGmLKpWHhr0gurq/Eovrqojqn+YSDpyxqRGXYgqs1BCC062hpR5v7lPXeqVhATKL9+t3X3raQIS9XmXRO+wneIkzWVegfSUEpF3MrIlgzrx6nNtdj5dwaVIRMDKeyGM26BYnRg5q6FY01OKmxrmT0H/xCZSSMkCmhx+wxdHRoqrC2eQ6klEUvMD1eONhUXYmT6quQcVzPNyAi7TqsNf/TJ69rD/ut6OMexZiY9AGAAcd9vwyF417KF4YUBEdpDIyksHROFS5YsxRnLmvGwvoqRG0LIC8cOTySwrO7uvHzR7fgL7t6UBG2T8gmEhEc18UblzaDSBSqrCpvG1AZDaMiHMKBoVEIKY/aWIrBkASsO6lpHHDKMbRfCHPawkY8uasHZFsgZqGcrDZCkeVbncxFANonNp+OAQBTRyup9990e3xHV9/7BDIgQAT1drURGx8853S8+4yTEQuHJg3VauNRnHfyEqxftQjf+d1juO2R5xALWTMGgdYaMdvEG1csLCn9Bz8TNg1ETAkd1ORO+IzjatTHI1jT3DjOIy9XrgQAzlzWjNseeW7snDOYOes6H2FGByGhJzUBgX3Yd2joQhkKLdDK0VII0T+axlknzcUPP3gx3nvu6YiFQ1CaofnoxgpmrxBTSImPX/hGvHvdcgymMjPS2oD+lzTU4KTG2pLbVy/VLFAZDXu5gEnYKeO6WNpQ7S/9lre/mfw5XjmvHvOqY1446FkBqbJpMIlzLvrmj08DEY/NDub+0dHZyQCQdZz3AWBBxP2jaVx2xipc/963Y35dtVds6ce+k3n9RH5+nj2AXPX2N2JFQxVSWXfawvNKq1ycvrgRUojy2FcixCzPB5jMPCmlsXZ+Q1nCv6nCwYht4/TFTUE46FMAlLTCMuWIyz1T30HjANDm1/a/65s/W8Kgc+E6NJjKiMvPXI1PXbQeJCQ0+8WW+TolDIQsC//4ltfPqNSaGbCkzGXXSq1dgUDrKyugJ1n/YmaYUmLNgoay2/+J4eA5KxdCCsr9nwChnSyU1u/+l1tvjfo+AOUA8ID/mlLuO81IJDw4mlJnL2umf37Hm7yJYJ62Bns3wHjTqsVYO78eo1kn72sQebn/pqoYVjXVl9W+Rk05qbY5SqMuHsayuXVli/8n88MA4JSFczGv2s8K+m8p5WiyrMUvHJBneybfKxoRALB50ybFzJRl9xLHcVEZMvHpd74JQf5nppOv/aKIC9Yu9RZV8ryO8O3rmvlzEAl5kUS55remInqUdIPwb2FtBapjEX8L0vIjgPxoIBqyccZJc5Fy3CMFM8wspIGUoy4e7wT6Hb0X//tPFxHTGUPDw7j0zDWiqbbKc+hO4MGC756zajHqYmE4SuUpSI891i2eO47aysMABnKWdAwAXK2wcm5tLgSbbeP8NUthySNJLPJyAnBd920fvvHGSGAGxAafBRzF69mwIrURS19y+ioqREWr3+6OOZUxrJ5bi7STX42dqzUqQ3bOvgoqjzYBQCxk5ppOx2YABFHOPM2mEWj82gWNWNpQjbTjBgQmtJtlIeSSXb2hUwIzIOZsbWEAUExvGc26OGtZM9dXxgpW0Ro4U2sXzIFS6vjFFUTIOi4W1VdiQV11+ey//5O1lRUwJI1jIaUZcdvC0rm1ZQPosdPnDNMw8OZVi/xoQARMqqVtkxLYAAAHOjtJdHS0qsR17WHNfKZ2Hbxx6XwqJO0Gc3NycwMsQx63jo+IkFUaJ8+rhyhX+DcuVepl+ybeX0NFGE1B9/Es2/EmuJ3z15yEyogNd0wUxlpDKb2eAGwGtACAtBpd5mh9UtwkrJxXT4VEdXAzi+bUoCpiT5pUGU+u3m+f4tN/uTNrFdEwQpYF7d+3IMBxXSyeUwPLNMvqoB6LRTUDzXU1eP3iuUhlHEhBvh/gAsynvff6X1UhmfQA4ECuZWnLOfGIaqyqoELSbnCdmmgYTVUxOK4+psYorVEVsbFq3pxZQa+2IWEKMdYFhNaMZX52kmfpSQDBEvY7T13uZYN9bLBymYVs7Mv0r8yFgazxOkdrNNdWsmUax1z/nqkfIKXE/JoKOEpNKVRBhIzjYsmcGsytqZwV4ZUtBWx5pASdmWFIgWWNNbOR/cflYQDgDUvnY+mcKt8BB5hZS9NGCmJNzmnUhNVKuWiqjlEQvxcjQzWvOn7MbisiwFEKLfPqvMaHMtr/AHjRcAjxSMivDSQorVERsnLr/7N5vzulGbZl4eLXrUQm63jOIBGDCKT0WgAQ77zmpjgrvVS7LpqqYkWt+5tfWwkvoKJj2H/C6qa6WWVPQ35RiAdQjbp4BHMqYmXNUOZ3797r29YuRWNl1M8MMrHWcEkuIwDCUeZcpblBsEZDVbwoqA7maG5lDJaUUy6cKMWoDFtY2TQ77L/2pV5TEYXSGoK8uogFNRWwzOn3JjBzSQ8GIH/vg5p4FOevXojRrAMpBLFyAa0Wf+SGG2LCNnkJCFFDAJXhEBUDAcHlGqvjiPn78NBk9t9VWFBbicaailmlXVFDeCePEUGzxqK6ymk7gEFepVxP9LdnrPHKxRQTawWluWHHULRO9Ge5CdIkSwodn6TQo5CjIhxCPGR7sf1R+XXf/jfVl2/5dwrfpbYyKA8HBAhL/Ahgutq4v28A6axThpCQsaC+Gmcvm4+RTBbCc/6iNWFrvohY5lwmwJSerSuOCfAdKttEbTR0ZPeuCTwhAKwtc/w/2YhbBgCCYkbINNBcW5l3BBCYiQc6d+Bd1/8cyV/cl9vEqtTj0rPWIGRKUlozScPoGcnOF6zcZq00oqEQV8WiRctsefZUoL4iDKWPTgm7WqMibGPlLIn/x46GqgoIAbhKozpioynnK1Fe4E9lsvjefU9ASIn7nt+Fv+zYW9IoJ2CB1c2NOHv5AgynsywNA4pElchqUcMADALJYk66/6xzKmJejd2YyRP+8uq86hgaq2aPd52rDg5bMISAozTmVERQEQ3lpScB0z2+Yy9ePtiPeMgCA7jr6ZeKpmjHG5eddTJMf5u8uGnWCS1kiAGYglBMAARY9wTMR9n/rOstr5qGMSvs/1gEVMUisE0Jx3XRXFMBIpGX9gbT+eALu6B9QIQtE4/t6MKhwWF41XOlYwFmxtqFjThzaRNGMg4At1ZYkqJKKUQjEZiWWfTkRl084i+v8lGTtXZB46yy/cE8RC0DIcOr+28OIoA8AC+ER//P7O6B7be0m1Li4NAofvvsdhQj6Xa8eyIS+OBbXs+GIDia40IAdrCrZjFFH7BdXTwKy5BHLa/GbBOr5tWXixmPCYHqeARxvzJpYW1V3mEfALzUdQBd/UP+M3sHV1uGgXu37ICrVGn6HCb4Ai3zG7BhRTO6Dw+HBRNJlKCkObh8TSwM2ziSDAqWV5uqYmj2J1fMEgQEtxGxTMTDNiwpMN+PAI4ntwDgW/cdQto5sv6hmRG2DLzU3YfndnePixRKOTZuOA21UdsQEwXERYZALGQjFjKhWfubNgOOq7C0oXpG2bXiZwM92qyJhhCzTcz1I4DjsWXgxD6zuxtiQme9V/KucU/gDJY4LwAAS+oqkfzbc1mA2S1JeooCe+ppkxrTd6+1zsX/+crfO3Wj+PF0cP3aWBi18QjikeNHAEFNw3AqjRf398I2x6e/te8MPrRtD/qGRnIOWmmTXIyzVy1xhQZSKEGKMtiu3bJMVEdsKMW5ZoawbWK132CRL/sHzaqlChcbKqKYWxnL5dfzAc0rBw/j4FAKphzfYcwALEOie3AU93fuKLkzGDCUBkaEo3QqaOQoBeoAoNrfQ9eL/zUa4hEsrKvKK7kS3Gcqk8GP73sMe3r7x127WH5Ac20lmiqjebFU8P7z+w4i5apJfRpmr27vt8/ugNa64Psd5sPHAhgUBquUp53ExQ4BAwejJnZkE+Wsq7CkvgrRkA2dhzMahI8/uO8JfOn2B/FfDz09LdMxE00BgFMXNeFv3tCSl5MavL1ld8+Un9XMCJsGnus6hOd278+xYYnHIWFLccCb2OIjMBDe3Kq4vzrm2f81Oft/fGoVRNh/eBB3Pr0NC+qq0bn3IFzXzZ0QVqzopb4yhhV+mjqfymbHdbH9wOHjbDDhHSxxVxmcQX/0CRZyD5FAKpMmpVQpmAc10TCk8BZXbEPi5Dztf2AnH35xFw6PZmAbEr0jaQykMigqDSA4bub41w8+s7d3APsHRo5Z/6A1I2KbePDFPTg0MFxKZ5ByAEin0j0ERiabheuqooaCgYCrYyGYQsBxNWpjISzOs7wqoNM/79znHwMDjGQc9A+NFjmE9e4tH4czAOm27l4MZ7LHPHiCAZhSomdwFPdu2VYqZzAIv7IAdom6mLmLXUcpkNBFrlfJJYOi3tYrGcfFSfVVqIofv7+OfQANp9J4qbsPln+si9IaadfFbBtbdvfkZdM1M2zTwD3P7kDWdUuZGRwCsF8MDdPLDB7SJKFBJeGfikgYEctExlU4ubkhR4f5UOvuQ/04ODQKU3pduxqAmkUHkHvePGNbTy8MKfPya0KWgRf39+LxbbsBoNiLYcHFuwD0iressA4YUuxLOy6GR1NcZJcaABAPWYiHbRAYq4P27+PaVu91e08f0mM2P9CakXXVrBA++00ivYMj2N07CNuQedl0AsBEuOPJF6eVCzlBAOwkorT4VGtrSkBsc5mQzjhFhV7wXLZpIGpbqAhZWN40vf76bd19uScgAlylMDgyXGwfME8AeK87DvShbzQDOa6hZOqhfGfwsR1deKnrQNFOMp0wngcAwQAMKbZoIaCOaoQukpYIgYjlNYrUV+ZXABJQ686evhy1Bt9wNWYHA/ivz+3uOWYDzGRDEmE46+L2Pz+PogvBd1P8ZBAgiZ92XRcZVxXdAwlkVRUJYVlDNYJau3yodWg0jX39QzDlkeXk4EzV2TACED+/vzfXkZvvUJoRtU38fusr2N83ABJFCQkZRw6lfi4HgKqw9Ux6ZCQzODIqxuRriqomdbFwbv0/39/r7h9G32gahggKSggMwvBoelZovyBgJJ3Bjp6+oxaA8hmmlDg0nMJdT73oZwaLRlKvANgeAIB+vrZxl9a8VRlW0ckncN7e3LIEZ69YNIbejx9b7+0b9HYcE+MXrw8PjcwKBxAAdvb0omdwZBxL5c2OrBG1Ldzx1DYcHk4Vo2QsuNifiWiUmaXY0NYm6bzz3LTSD404qui+VGDqT144F/OC8uo873vngV7vgITcN7xXZxZ06AWTtmV3j18AQjO6hmVI7D08hF/+uTN3MFQRxuZgAnOG6vDw0B8O9vXnJ48CaUy+SAts68sH+/3iCh4HjNFM+RNBudPI9/T42b8T2B01ZKHjsU509w14axyFUcnA/jsAHgx+TmzetEkJAHv/+KdHoHWvZxaKH4OQn8rNd3KVVug6PAxDjF9cEUToHx4pRfx8zJkl3/4HWcqZ1vx76WGBQ8Np3HjfE4X0BXiM9/+Cd5wMWICIFbPAs7860FARfQAASyFmSWB1BIr9wykcGByBIUXOS81NfJkTQYGGbu/uRXdg/0/gekozKsI27tmyA4+8sNM71vbEURBc4G4icr3Ik7w9Yx944AEBACsaqm73TcCsqcsNhN03ksJgOjtuB0z4+/n2DY54S8JlooDgfp58uQsZVxXkPhiAlBLX3vUoDg+NFCIsFH74d8dYQAgAOPfccxUAzG+o+x0A3wyAZxMD7O0d8FLAYyKGYD+BlKuQKfJKZj72/5nd3ZBCFsRms9+HuLd/BN/49R9zJXUz3XjdV+pnADzFzEREKgcAImJmlkR0AMCdE3I2s2Ls6R2AqyccXeTvXzycymA0kx2PmBLSPxFwaGAYL3b3IWTKgoVuyu+XvO+F3bj+zgdzDTUzuH7whZ8F9D+WFiaOW4/xXhmya97rrkP9uXTwROcr5SoMprJlub/ANG/Z043e4ZTvoxRuKK1RGbFx25868a27HvTrIKblEwTe/wiAjonKLcZ45cr3DB8E8HTw++UHgIeA7oERb3FlwnNLIqSyLnoGhspiAgKAPr5jHxQXx3nSmlEZCeOWRztxze0PIOubwuDchjzoHwDuJKJXmFkQkZ6KAQQROQBunA2OIPsTmspmcWBw1AsBJwGI0hqHgqqgEiMg2NnU6/+TRavo0VqjKhJGxxMv4qM/vgOdu/fnzm0IIofcQR5j/vQROX5vXPZsCgBonwV+DmDfGM+xbDEAABwaHMHhUZ9ej5Iwg0HY2ztQBvr37mVHTy929w3CLsIWexPNQVUkhOe6+vCRn9yNr/3yD+jc3Q1oDSnoyEEeR/6U8GT4MIAHxzp/wTAmaFPgDPYz8/cBfKWcAAiK1w4MjGAk4yJkmZNOMIFwwGeAUkaC7N/gY9v2IpV1YZvmcVc2CwGCiOW10P3qyW34zZadWNlYg7ULG7CqaQ4W1FUhHjIRtm0opSirNMK2fV11NKSZWU4068bkwGbyzcDHANSPkUXpQ0ACuvuH4CiFCFlHTTAzYEhC1+GhXNl4yehfELTWeHjbbpiGLFl7V8A8lRGvl2JLVx+e3HMQAkDEMmAZAmHLUmRaMj0y/Jff/e6W/8Yk2j+pp0/k7xRPdBDAt3zBlzUk3Ns36Pct8KSJIlNKdB0eRv9w6fyAYI/gnT19fvhX+sZWpT07H7EMVEVsxCM2SAhkNdA3kqaBVBauoq9i82Y30TH50bHG1M/HBOAGAB8G0OyDoKShYaDM+w4PTUntHgMIHB5NYU9vP6rjUd8roJKw0+YXXsZIxkVV1C7bzibesT5jTSKrUCQiOZv+431f3PjrTeoVkRxzVuAxGWACCwwA+DIwhfqVwMPWWqN78OhFoImfSzsKnXsOlIwBpCBkXRf3d77iF3/MmpwZM4i0Usq26PNExNi0aeo5PjawWAD4CYBH/WSCKt1TeDM6nM7gwMCIVwd4DHdRCIFn9/aMyx0UTeN8aT+1cx+2HziMUJG9/2nOmzZDEQHt/PSeT298OJFol8kxcX/eAPBZIHAcPglvHbnkuZbDwykMprK58winEohtGni+qxeDo2mvkqaotsl7ueeZbV56evZsaaeFNIR2MgfjRuhqMNPq1Z3HnApxnCyc8sPCx3x/QJbKIQzuen//oLfHLU3d/Bn023f1D+PJl7vGaWkxmCloUH14215EQ9as2dWMmVlaNkmtPn/HZy7vSnR0iGQyqWcMgAmmoA1eLXlJQBAoe8/ASF5HzhEYGoT7t75c1HxAIOs7//I8ekcyMGbJjpbMrMxwRKpM6u7ff+H9NyUS4w+JnjEAxpiCIT8icH2lKwns9/UN5iVNpRlRy8TDL+3Gvt7+onTaMhhCEIZSadz97I5cQmb2UH/2UH1MfATAcal/Ogww1hQ85EcFRXcIA5nvHxj2GyyO/zyGJBwezeLup14ap62Fc/4883/Xky9gd++Qn/qdBdoPaGGaZGjnox1XXbk7kWg/LvVPCwBjTIEE8FUAv/FzCKp4APA0uGeKVcCp4uGwbeCuZ7YfcQYLJCHP9ntRScdjzyNkGdCsZ4Hw2TXDMYMzqf+49wsf7NjQ1mZ0dLTmLRcxDYGMpf0rAbxcLH8gWAUcyWRwKLfGznl9zzYM7OkbxH8++FRBy6q97WsI7Y9uwSu9A37oV267r5VhRwxkRv64fkX800i0y83JTdNSSjFNrdR+gugAgEsBDBcnSeRdrncohYHRNCSJvCdbaY142MbPHtuKF/f2eAWVJygp7e+kuutAH/7zkS2IhW1orcssfNbSDEm4zi7KDl+WbG3NYnUnY5ot/tNO7Y7xBx4HsBFH1gq4kAwAAPsPD2LEP/NuuhnErGZ8/Y4HMZrOgDBzEAR1eMyMa+98CEMZ129NKyvtayENAWAwJvnvfp/8WFci0S6Rp90/IQCMAYFBRL8A8M9jTAEXTv+9OsDpnDo+VmOjlonOrl587fYH/B1Jpw8ChleIIQXh2/c8gkd37ke8/HG/JiFBRC7Sqcvu+MyVTyTa2+V07P4JA8AHgeuD4PoJkUHBZueVQ/1+ODD9S3q1dCH8tnMXkr+4D9ls1m8wyW93Ua05V3b+Xw89jZ8++hwqw97Jp+XkfRBBGoYw2Nl4f/JDd29ou9/IJ96fMnI6wVsKzEEbM9sAPuODQOAE6geEn/bd3Ts4aRnYtEAQtnHHU9vQ3T+Mz158DhbOqcmxRFDlQBPonoi8liyt8Z3f/Qm3PLwFsZBV3nw/M0MIlqYtTM7+42+v/sBtG9ruNzYnzzuhvjgqwH2R7xgqZv4GgM+eCAiCypPhVBpXfPeXODiSginkCfWsSyEwnM6iMmzh0jNW4+LTV6HOP/dvqvH0zr344QNP4rGd+1ERtkt+5NtEm08kSBommXD/8beffd+NG9rajM3J5Ak3RVKBwDkWBF8CkBwTHk7LzARbyG7d041/uPlOGEIWZOKlIDiKMZLJorEigrOWNOGs5QuwsK4KVdEINDP6hkbwwr6D+OOLr+Dxnd1wmBGzrbLSPrPn8BHBtdnd+JsCaX6hTEAuR8DM2jcHX2bmwwD+wweYwphGhLwiAPL22RvNuqiKmAURgNLeMfBVkRAG0w5uf2o7fv30DkRMkdumdiSdQcpREIIQtS1YvhkpZ5wvrZAEeIAy2ct+0/aBezzNP69g7dBGoS7kJ4oCn+DbzLwbwC0AKuGtH0zrtzr3HvC9fy4glXoCNSShMmL7Xj5jKOPtMGAYBir9BI8uI+UHGT4jFDWgnZ0V0Jfd3vaBxwup+SccBeQRIv4awJsBbMWRtPFx51QKguu6eLHrEEwpi7LY4m0wybklY4PIW25mzrfZoqhhHgPaDMcNcrN/EKmBc27/7PseL7TmFw0AE0LEJwGsB/AL3wwEJmFKRzeI/3cfHvL32SuFts2OTlhmrUhKYVi24Mzo/2mtTV/w++THuhLt7bIQDl9RTcAUIJBE1AsgwcyfBPB1AKGpogTNgCRvl43BdBZVkdDsOUKuyJ4eA9oIRyVcp1s62Y/f+4WNHX8A0NbWNmVB56xlgAnmgPx+tOsBnAPgT1OxQZDxe/TFXRAk8Fcgel/rDTJDEUmue3uVkT3z3i9s7EB7uwRAyRmkd2cFA0xwDoOOoyeYeYOfMPosgEgQLjKzEEToGxrBln0HEbKM3IHNr1GlV0QkzHBMaifbJXT6S/d+buOPACDRnl81z6sCABPYQBBRFsBXmPlX8GoLLvHDNGVIokdf2i16BlOojNivSfpnsCYARigstetquNmbIlon7/r8xn1oaxMAUCrhlxQAPgj0mKTRcwDexcx/A+BqQ4p1APDbZ7cr4dGGeI0JXgEgwwp5tk25vw8bYtM9n37Pw6XW+oJnAmdIgcHuJPrul16yL1y27IoX9h+66n/fdm8Law3tZDQzmIgEZtGeRTPw7jQBQtphr1hdq4dN8LW//dyVv4YneYn2hAZRWehuFuwBwDLXtLjuw5G3Js6+zNX8UZLG60AElcmAwS55jCBeFVIHMxgshJTSDkE7WRDrP5Cgb/3+c1fe4SGBKZHoEDNdxn3NAMAHAQEQgkixF/oYj8WWXJjJ6g8z8FZph2ztONBOlhnQ5IULs2k3s5zQiUhK0wZJCZ3N9INwpy1x028+c2WwO2fZ6H7WAmDMNFKio0OMnZyLrvmvllHttiqt/paEbBGmBa1caCcLZla+GSk1IILIxjtqTwgpDAtCSriZFBPRY1KI9kpD/PKX//qeXf5XKNHeITpaWwtaPfXaAsCY+0q0t4uOzk4Oypza2tutJ3Zk3phhfrvL6gJmtBh2WDAztOuAlesBgoj9XngCc7AdKc1Y0F6BQE7YXv2AkMIwIAwTAMPNpLKCxJNS0D2mwN2/+cyVTwQSTiTaJQCUm+pfbQDIjba2NvEAIMamQu+//37j+j/tXpMiOkdpvUFrvY5BCww77AmcNbRSYKXArIMcMyO3yfykGWY68g//YE0ikBAgYUBICRCBtYKbybiCsEMQPQ6IzRGoh++6euMLY6+5oa3N2AxoFDmR85oHwDhWSLQLJI6Ok9//bzfFe7R1Ugp6jcFY67BYDubFinUTEeKChA3DOCLaKRnYL/ZkDVYuwJxi5kEpxR6t6RXboK1ZpTvDkrb8r3D9zk984u0ZTBD6uYBOznKhv1oBMO6+29ra6AFAbN7awpiEXttuvjn04LZ07dy51Q19g6kFw1rXRuxQJWlVC+YKBocVYICIDWYHJEYFYTAL2ZtOpQdrotaBWMjeve/QgYMPnNtyiM47eiUu0d4uD3R20qtN6GPH/wfzTUBtWJwleQAAAABJRU5ErkJggg==">
<style>
  *{box-sizing:border-box}
  body{margin:0;font-family:Tahoma,Arial,sans-serif;background:#f2f5fa;color:#1d2433}
  header{background:#2b59c3;color:#fff;padding:18px 16px;text-align:center}
  header h1{margin:0;font-size:20px}
  header p{margin:6px 0 0;font-size:13px;opacity:.85}
  main{max-width:720px;margin:0 auto;padding:16px}
  .card{background:#fff;border-radius:12px;padding:16px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  h2{font-size:16px;margin:0 0 12px}
  .btn{display:block;width:100%;padding:14px;border:0;border-radius:10px;background:#2b59c3;color:#fff;font-size:16px;cursor:pointer;text-align:center}
  .btn.light{background:#e8eefb;color:#2b59c3}
  input[type=file]{display:none}
  .bar{height:10px;background:#e8eefb;border-radius:6px;overflow:hidden;margin-top:12px;display:none}
  .bar div{height:100%;width:0;background:#2b59c3;transition:width .2s}
  #status{font-size:14px;margin-top:8px;min-height:18px}
  ul{list-style:none;margin:0;padding:0}
  li{display:flex;align-items:center;gap:10px;padding:12px 0;border-bottom:1px solid #eef1f6}
  li:last-child{border-bottom:0}
  .name{flex:1;word-break:break-all;font-size:15px}
  .size{font-size:12px;color:#6b7385;direction:ltr}
  li a{background:#2b59c3;color:#fff;text-decoration:none;padding:8px 14px;border-radius:8px;font-size:14px}
  .empty{color:#6b7385;text-align:center;padding:12px 0}
  .row{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
  .row h2{margin:0}
  .small{width:auto;padding:8px 14px;font-size:14px;display:inline-block}
  .brand{display:inline-block;background:#fff;border-radius:50%;padding:6px;margin-bottom:10px;box-shadow:0 2px 6px rgba(0,0,0,.2)}
  .brand img{width:60px;height:60px;display:block}
  footer{text-align:center;padding:8px 16px 24px}
  footer a{color:#2b59c3;text-decoration:none;font-size:14px;direction:ltr;display:inline-block}
</style>
</head>
<body>
<header>
  <a class="brand" href="https://merabti.com" target="_blank" rel="noopener"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAqr0lEQVR42u19eZhdVZXvb+19hjvWXKlKJZWBzCkSwKCAQgKKPlAB2+5bH9AixqlbX6vYbTuhVq4jLc3jteKAogjSra/KT5FmUBEhMgkiU6gwZIBMlaokVan5Dufsvd4f55ybqkpVcqtyhwJ7f199N/nuveees9dv/daw19qb8CocbW1t4gFAzNnawh0drWrsewTg7677YY2m6NxRJ7Ms7cq5YVPMz2QzzUracRKIGuAYEdkESAAAk8vQaYdpiLVOSe32h0OhXUMZp6vKwL6sxPYaU3T/5yeuGJx4L4n2dnmgs5M2AxrJpH61zSW9moS+taWFOloTGiDOCeCGG2KpkcrlKa1PZfA6MK3QSi1jUJ0QFCHDAoNzD8rMYGaAecJMEIgEyP9g8C47WTBjSBB6IMQ2A7SVmZ+MWOLp0xba25OtrdkxNykSLS3U0dnJrxYwzG4AMFOio0N0JBIadEToF379luWaeH2W8RZoPoNBi2UoBIDAWkG7LqA1mHVO0uzJlCh4ZGaaAAAfEt7HyUcZgQQJARISJA2QEIDWUNm0C8I2SeIRknxfVNoP/fpTl+05CgytrXoMnv4HANPT9iP0/q5rblk1wninw3yR1vr1ph0OMQB2HGjlgplV8ETECFS5UM/HAJjBDBCDmYiEFIYBYZhg1tBOtp+IHrUl3W5L856xYEi0t8uJIP4fAEwl+K0tFNj1K6+/uarHsd+ZdTJXaNB6aYVCrBWUkwVrrTzFJfKfo9TP4oGCPeIQQkphWSAiqGymXwD3WkL8tCGt7r0luTGdA8IsMw80WwSf3NpC8AWfuO7WpYez/H5X898L014AMFQ24wmdPFqefezFzAx9BAw2wBpw3U5B/JNqg2/r+PTG7tnGCFTmOfNsvE/1F15z25qM1h9j5kuFbcdVNgvtOoGmz0KhHwcMBJKGJYRpQqczPYLwkxqJ73Z89srdOSCU2Uco24T6D68Cpy4L/KsG/l6YdtjNpMBaK5/eBV7dQzNrFtKU0rahM5k+SfSDuojxf39+1eU9AJBItMuJ4exrFgBtbW0iuWkTg4gT1/2wpt+xPu0ofFRadnyM4F9F2j4NUiAoIaQh7TB0JtNlCf3N5ZGB73/7E5/IJBLtsqO99GahpJO8oa3N2JxMugBw/tdvuUIBSWGFFrvp0deu4KcEgmFIywa7zhMWq6t/8/n3/W4iM752AMBM2LSJkEzqd3z5e8syVvRaLYxLtOtCK8f1MnL02hb8JEAggjbssNRag5X6wYtd+z7f9Z3P9zKzBKCpBGxQ9Ekfa9/e9rWbP+SQvEYYZo2THn2t2PhpD0EEBjCadeA6rg6ZkmpqaykisD3M2atu+fjld/kYEUSkX7UA2NB2v7E5eZ77rq9/u3ZYVH6LhXm5cjLQSikikvgrHFIQRjIOJAGnNM/B2csX4OTmBsyrqXBDkYgxMjKKqmjom9sM44snE2WZWRKRerUBgBLt7aKjtVVddM3NZ46wvJkMa6WTGlEECNBfGd0Hmi8Ig6MZvGFRIz705nU47aT5R0UMwUcBPABgIxG9wswGEbmvDgAwU9umTZRMJvVbv/LjK10pvwshI8rJuAQy8Fc6AuFf+oaV+OQ7zoaUEsyAZgaRLwgigBm+sA0AXQCuIKI/FIsJCiuQtjYBIk4C+vyv/fjL2gp/UWfSYNdVRKUVPvmTzgC09nwpIoLwIa81lyz7IoXAwGgaV5y1Cp94x3owAKUZUhDkRDL0/m8AUACaANzDzB8loh8Vwzk0Cif7NpFMJnVbW5vxoLXoRrbC73fSo4o8R6ak9l4KAUcpDI1mIQgImQakFMg4DrKuBhEhYpswBEFpLr7wUxlcuGYxPvGO9dCaQUSQ4rjkK32TYAK4iZmbiOgrzCzYYwkulKIUTvg33hh5+HDo52yEL3JSwy4VmmHy9K4HUxk0xMNYv2IBzlg6H/NqKmGZBvqHR7GrdwCPbd+Lx3fsw+FUFvGQBUEEzVyU+0k7Cgtr4rjpw5cgErIBnnbAyz4QJIDriOhTzCwAcCFAQAWQvkAyqf/l1lujz+zDL9m03+aMDrulpnwpCClHQYLx7nUrcNmbTkFjdcWUn9998DA6Hu/Er//yIhzNiFhGwdmAiJBxHHz7iguwbkkztGYIMaMpZ98kGAC+Q0T/VCgQnBgAmAlEuK69PXT3jvTtbNhvc1PlEL7AUDqD5qoYrn7XerzO966V9iuBfCfLX9QHkaedAPDsK1245r8fwvaDA4iHLCitCwbI/tEMWl+/Ep+5ZEPO5p/gCJzDG4joY55jiHEVUtNmqRPN7rXdf7+8Z2fq/8Esn/AHU2mc2jwH33v/RXjdSfOhtAazN+FCEASR7wB6tlcQgZmhNGPtoiZ8/wMX4YzFDRgYTUMKUQDNB7KuRmNFFB84dx2YAVGYeMvwQfBPT7708jeJSDGfWCJtxs7ZBsDYlUwqWrr+h2RHL3VS5aH94bSDUxbMwfXvuQDV8aivacdPNQSAUJoRtkycu2oROvd0Y1fvIEKmxIm4BFIIDKUy+NB5p+HM5QuhecbUPxVrq3Asds6u2hXZxFmn/HFDW5uxa/NmXTIABIs6b/3qj5MUil3lpEdKHuMTETKuwpx4CN+68u2oikWgZ0CzgQNomQbOWtaM+57bjqGMM2MmIAKySmFeVQyfvfgcWIbpxfmFy32R1qCwKfTuwcxbd1av2P7UN69+ZqYgEDMV/pu/9qP3aCv8JZUZLbm3n7NCWuNL79qAuooY1MwdrBwT1MSjuOqCM5B1XBBmei2BVNbBu1+/CvFI2E/0FDjfRkwAxAUtC3XjnLofXPLvt75xczLpJhLtsqgASCTa5eZk0r343245ncn6vutkNWtd8px+YPf//qwWrFvaXBAHSwqPCc47eSnOXNKE4Ux22oAiAFlXobEiirefuhyMgtn+ycJdWj2vDi3z6yI9I87PPnpDe2NHR6tGW5soDgCYqWN1J1/+je9WD7t8G4SIsnJR6rw+ESHluFhaV4mN567z7GuB7sCz+4TLzloLERSSTzPdm8o62LBiAWriUXAxtB9HMpmAEOctn68UGQu2D6duaWtro0RLy7QKZPMGQKKjQyCZ1N0qfAPZ4RXKSbt+AQdKDQDXVfiHt5w+JrFCBWIW7zrrlszDSXOqkHbVtK6tGbANgQtPXVaCpJf3es7KRbJCKNc1Qm97xFx0dUdrq0q0t4uCAiCoUnnb13+0kezQ5U5qpCwLO4IIoxkHp8yvw7ktS8CF9a59ITIsw8CpCxqQcdy82UWQp/0nz6tHS3OjH/pRURVBM9BUU4k1zfVyaHBAsWF+8cKv3fymjtZWlUgkZEEA0NbWJjpaW/Ul37h5kQPz31U2w+QtSqAc2q+0wqVnnQwhBIqRxg/Cv5Pnz5mWG0hEcJTC+S2L/Xsr/lKT35KAs5cvJOW4BCHMFPON77n21ujq1av5qO6nmQBga0sLEcCDLr5FplmjldLlWM8XRBjNOmhpqsP61SeBGYXIrE0axgHAkoZahC2Zd3rYURo10TDOWbV4HEWXwgycsawZ1bGwyKRTrgxHW7oz7peSyaROtHaIEwJAQP3nf+3mS8kOXeSmRstWyUNEyLouLjptOUzDKJqGBeFfU3UF6mIRuFofd/FGCELacXBK8xw0Vlf46WYqyZwwgHk1lVjWUI2Mo6ROp5SSxlXv+MZP1nV0tKq2NhYzAwAzdXR28iXX31zlMK5h5XK5KnkIQMZVmFcZw/lrluYYoTiT6r3GIyHMqYjCUfq4OQECoLTG+pULc35EqUawvHzG0vlwtSawBknDSrn6OmYmYNPMGCDw+odH+VMyFFmonIymMhVwBuHVm5Y3ozIazlXRFG1SfQE2Vcag8mAAR2nUxcI4Y2lzyeh/ImDXLWpCyJBgkFTplIId3nDBN265NJlM6kT71AkiMYXnJzpaE/qia29drFh+3M2kNUGUrXqXGbClwAVrl5bs9wCgqSYO1nzMsFoKQtpxsbqpHg1V8ZLR/1gzAADL5tZhfk0cWVeBBBErlzOak++59tZoRyKhvY73PAHQ5ucbR1Lu56Rtxz36L0/DhiAg5bhY3liDlgWNfnatNLdSGw3nwTQEpTTOWNJUcvoPzI9mRsgysWZ+vR+6klBOVks7vKzHUR8AESfaJ3cIxWRhXzKZ5Iv/7acrtJTvUZkUT5XwCVbUgj8qCsIFso6Lc1cuhCFlrr6vFLTaUBWDJJELtyYbSmvEbAuvXzJ/3HdLzZAAcNrCuUdgQUTKybKj9acS19xYORULTEXrPORkPyktO6y11mM50Ktn8zq4sq7CaNbBaNZBynHh+gsyhdRQpTXiIRPnrFxQ8gmujoZgGmLKpWHhr0gurq/Eovrqojqn+YSDpyxqRGXYgqs1BCC062hpR5v7lPXeqVhATKL9+t3X3raQIS9XmXRO+wneIkzWVegfSUEpF3MrIlgzrx6nNtdj5dwaVIRMDKeyGM26BYnRg5q6FY01OKmxrmT0H/xCZSSMkCmhx+wxdHRoqrC2eQ6klEUvMD1eONhUXYmT6quQcVzPNyAi7TqsNf/TJ69rD/ut6OMexZiY9AGAAcd9vwyF417KF4YUBEdpDIyksHROFS5YsxRnLmvGwvoqRG0LIC8cOTySwrO7uvHzR7fgL7t6UBG2T8gmEhEc18UblzaDSBSqrCpvG1AZDaMiHMKBoVEIKY/aWIrBkASsO6lpHHDKMbRfCHPawkY8uasHZFsgZqGcrDZCkeVbncxFANonNp+OAQBTRyup9990e3xHV9/7BDIgQAT1drURGx8853S8+4yTEQuHJg3VauNRnHfyEqxftQjf+d1juO2R5xALWTMGgdYaMdvEG1csLCn9Bz8TNg1ETAkd1ORO+IzjatTHI1jT3DjOIy9XrgQAzlzWjNseeW7snDOYOes6H2FGByGhJzUBgX3Yd2joQhkKLdDK0VII0T+axlknzcUPP3gx3nvu6YiFQ1CaofnoxgpmrxBTSImPX/hGvHvdcgymMjPS2oD+lzTU4KTG2pLbVy/VLFAZDXu5gEnYKeO6WNpQ7S/9lre/mfw5XjmvHvOqY1446FkBqbJpMIlzLvrmj08DEY/NDub+0dHZyQCQdZz3AWBBxP2jaVx2xipc/963Y35dtVds6ce+k3n9RH5+nj2AXPX2N2JFQxVSWXfawvNKq1ycvrgRUojy2FcixCzPB5jMPCmlsXZ+Q1nCv6nCwYht4/TFTUE46FMAlLTCMuWIyz1T30HjANDm1/a/65s/W8Kgc+E6NJjKiMvPXI1PXbQeJCQ0+8WW+TolDIQsC//4ltfPqNSaGbCkzGXXSq1dgUDrKyugJ1n/YmaYUmLNgoay2/+J4eA5KxdCCsr9nwChnSyU1u/+l1tvjfo+AOUA8ID/mlLuO81IJDw4mlJnL2umf37Hm7yJYJ62Bns3wHjTqsVYO78eo1kn72sQebn/pqoYVjXVl9W+Rk05qbY5SqMuHsayuXVli/8n88MA4JSFczGv2s8K+m8p5WiyrMUvHJBneybfKxoRALB50ybFzJRl9xLHcVEZMvHpd74JQf5nppOv/aKIC9Yu9RZV8ryO8O3rmvlzEAl5kUS55remInqUdIPwb2FtBapjEX8L0vIjgPxoIBqyccZJc5Fy3CMFM8wspIGUoy4e7wT6Hb0X//tPFxHTGUPDw7j0zDWiqbbKc+hO4MGC756zajHqYmE4SuUpSI891i2eO47aysMABnKWdAwAXK2wcm5tLgSbbeP8NUthySNJLPJyAnBd920fvvHGSGAGxAafBRzF69mwIrURS19y+ioqREWr3+6OOZUxrJ5bi7STX42dqzUqQ3bOvgoqjzYBQCxk5ppOx2YABFHOPM2mEWj82gWNWNpQjbTjBgQmtJtlIeSSXb2hUwIzIOZsbWEAUExvGc26OGtZM9dXxgpW0Ro4U2sXzIFS6vjFFUTIOi4W1VdiQV11+ey//5O1lRUwJI1jIaUZcdvC0rm1ZQPosdPnDNMw8OZVi/xoQARMqqVtkxLYAAAHOjtJdHS0qsR17WHNfKZ2Hbxx6XwqJO0Gc3NycwMsQx63jo+IkFUaJ8+rhyhX+DcuVepl+ybeX0NFGE1B9/Es2/EmuJ3z15yEyogNd0wUxlpDKb2eAGwGtACAtBpd5mh9UtwkrJxXT4VEdXAzi+bUoCpiT5pUGU+u3m+f4tN/uTNrFdEwQpYF7d+3IMBxXSyeUwPLNMvqoB6LRTUDzXU1eP3iuUhlHEhBvh/gAsynvff6X1UhmfQA4ECuZWnLOfGIaqyqoELSbnCdmmgYTVUxOK4+psYorVEVsbFq3pxZQa+2IWEKMdYFhNaMZX52kmfpSQDBEvY7T13uZYN9bLBymYVs7Mv0r8yFgazxOkdrNNdWsmUax1z/nqkfIKXE/JoKOEpNKVRBhIzjYsmcGsytqZwV4ZUtBWx5pASdmWFIgWWNNbOR/cflYQDgDUvnY+mcKt8BB5hZS9NGCmJNzmnUhNVKuWiqjlEQvxcjQzWvOn7MbisiwFEKLfPqvMaHMtr/AHjRcAjxSMivDSQorVERsnLr/7N5vzulGbZl4eLXrUQm63jOIBGDCKT0WgAQ77zmpjgrvVS7LpqqYkWt+5tfWwkvoKJj2H/C6qa6WWVPQ35RiAdQjbp4BHMqYmXNUOZ3797r29YuRWNl1M8MMrHWcEkuIwDCUeZcpblBsEZDVbwoqA7maG5lDJaUUy6cKMWoDFtY2TQ77L/2pV5TEYXSGoK8uogFNRWwzOn3JjBzSQ8GIH/vg5p4FOevXojRrAMpBLFyAa0Wf+SGG2LCNnkJCFFDAJXhEBUDAcHlGqvjiPn78NBk9t9VWFBbicaailmlXVFDeCePEUGzxqK6ymk7gEFepVxP9LdnrPHKxRQTawWluWHHULRO9Ge5CdIkSwodn6TQo5CjIhxCPGR7sf1R+XXf/jfVl2/5dwrfpbYyKA8HBAhL/Ahgutq4v28A6axThpCQsaC+Gmcvm4+RTBbCc/6iNWFrvohY5lwmwJSerSuOCfAdKttEbTR0ZPeuCTwhAKwtc/w/2YhbBgCCYkbINNBcW5l3BBCYiQc6d+Bd1/8cyV/cl9vEqtTj0rPWIGRKUlozScPoGcnOF6zcZq00oqEQV8WiRctsefZUoL4iDKWPTgm7WqMibGPlLIn/x46GqgoIAbhKozpioynnK1Fe4E9lsvjefU9ASIn7nt+Fv+zYW9IoJ2CB1c2NOHv5AgynsywNA4pElchqUcMADALJYk66/6xzKmJejd2YyRP+8uq86hgaq2aPd52rDg5bMISAozTmVERQEQ3lpScB0z2+Yy9ePtiPeMgCA7jr6ZeKpmjHG5eddTJMf5u8uGnWCS1kiAGYglBMAARY9wTMR9n/rOstr5qGMSvs/1gEVMUisE0Jx3XRXFMBIpGX9gbT+eALu6B9QIQtE4/t6MKhwWF41XOlYwFmxtqFjThzaRNGMg4At1ZYkqJKKUQjEZiWWfTkRl084i+v8lGTtXZB46yy/cE8RC0DIcOr+28OIoA8AC+ER//P7O6B7be0m1Li4NAofvvsdhQj6Xa8eyIS+OBbXs+GIDia40IAdrCrZjFFH7BdXTwKy5BHLa/GbBOr5tWXixmPCYHqeARxvzJpYW1V3mEfALzUdQBd/UP+M3sHV1uGgXu37ICrVGn6HCb4Ai3zG7BhRTO6Dw+HBRNJlKCkObh8TSwM2ziSDAqWV5uqYmj2J1fMEgQEtxGxTMTDNiwpMN+PAI4ntwDgW/cdQto5sv6hmRG2DLzU3YfndnePixRKOTZuOA21UdsQEwXERYZALGQjFjKhWfubNgOOq7C0oXpG2bXiZwM92qyJhhCzTcz1I4DjsWXgxD6zuxtiQme9V/KucU/gDJY4LwAAS+oqkfzbc1mA2S1JeooCe+ppkxrTd6+1zsX/+crfO3Wj+PF0cP3aWBi18QjikeNHAEFNw3AqjRf398I2x6e/te8MPrRtD/qGRnIOWmmTXIyzVy1xhQZSKEGKMtiu3bJMVEdsKMW5ZoawbWK132CRL/sHzaqlChcbKqKYWxnL5dfzAc0rBw/j4FAKphzfYcwALEOie3AU93fuKLkzGDCUBkaEo3QqaOQoBeoAoNrfQ9eL/zUa4hEsrKvKK7kS3Gcqk8GP73sMe3r7x127WH5Ac20lmiqjebFU8P7z+w4i5apJfRpmr27vt8/ugNa64Psd5sPHAhgUBquUp53ExQ4BAwejJnZkE+Wsq7CkvgrRkA2dhzMahI8/uO8JfOn2B/FfDz09LdMxE00BgFMXNeFv3tCSl5MavL1ld8+Un9XMCJsGnus6hOd278+xYYnHIWFLccCb2OIjMBDe3Kq4vzrm2f81Oft/fGoVRNh/eBB3Pr0NC+qq0bn3IFzXzZ0QVqzopb4yhhV+mjqfymbHdbH9wOHjbDDhHSxxVxmcQX/0CRZyD5FAKpMmpVQpmAc10TCk8BZXbEPi5Dztf2AnH35xFw6PZmAbEr0jaQykMigqDSA4bub41w8+s7d3APsHRo5Z/6A1I2KbePDFPTg0MFxKZ5ByAEin0j0ERiabheuqooaCgYCrYyGYQsBxNWpjISzOs7wqoNM/79znHwMDjGQc9A+NFjmE9e4tH4czAOm27l4MZ7LHPHiCAZhSomdwFPdu2VYqZzAIv7IAdom6mLmLXUcpkNBFrlfJJYOi3tYrGcfFSfVVqIofv7+OfQANp9J4qbsPln+si9IaadfFbBtbdvfkZdM1M2zTwD3P7kDWdUuZGRwCsF8MDdPLDB7SJKFBJeGfikgYEctExlU4ubkhR4f5UOvuQ/04ODQKU3pduxqAmkUHkHvePGNbTy8MKfPya0KWgRf39+LxbbsBoNiLYcHFuwD0iressA4YUuxLOy6GR1NcZJcaABAPWYiHbRAYq4P27+PaVu91e08f0mM2P9CakXXVrBA++00ivYMj2N07CNuQedl0AsBEuOPJF6eVCzlBAOwkorT4VGtrSkBsc5mQzjhFhV7wXLZpIGpbqAhZWN40vf76bd19uScgAlylMDgyXGwfME8AeK87DvShbzQDOa6hZOqhfGfwsR1deKnrQNFOMp0wngcAwQAMKbZoIaCOaoQukpYIgYjlNYrUV+ZXABJQ686evhy1Bt9wNWYHA/ivz+3uOWYDzGRDEmE46+L2Pz+PogvBd1P8ZBAgiZ92XRcZVxXdAwlkVRUJYVlDNYJau3yodWg0jX39QzDlkeXk4EzV2TACED+/vzfXkZvvUJoRtU38fusr2N83ABJFCQkZRw6lfi4HgKqw9Ux6ZCQzODIqxuRriqomdbFwbv0/39/r7h9G32gahggKSggMwvBoelZovyBgJJ3Bjp6+oxaA8hmmlDg0nMJdT73oZwaLRlKvANgeAIB+vrZxl9a8VRlW0ckncN7e3LIEZ69YNIbejx9b7+0b9HYcE+MXrw8PjcwKBxAAdvb0omdwZBxL5c2OrBG1Ldzx1DYcHk4Vo2QsuNifiWiUmaXY0NYm6bzz3LTSD404qui+VGDqT144F/OC8uo873vngV7vgITcN7xXZxZ06AWTtmV3j18AQjO6hmVI7D08hF/+uTN3MFQRxuZgAnOG6vDw0B8O9vXnJ48CaUy+SAts68sH+/3iCh4HjNFM+RNBudPI9/T42b8T2B01ZKHjsU509w14axyFUcnA/jsAHgx+TmzetEkJAHv/+KdHoHWvZxaKH4OQn8rNd3KVVug6PAxDjF9cEUToHx4pRfx8zJkl3/4HWcqZ1vx76WGBQ8Np3HjfE4X0BXiM9/+Cd5wMWICIFbPAs7860FARfQAASyFmSWB1BIr9wykcGByBIUXOS81NfJkTQYGGbu/uRXdg/0/gekozKsI27tmyA4+8sNM71vbEURBc4G4icr3Ik7w9Yx944AEBACsaqm73TcCsqcsNhN03ksJgOjtuB0z4+/n2DY54S8JlooDgfp58uQsZVxXkPhiAlBLX3vUoDg+NFCIsFH74d8dYQAgAOPfccxUAzG+o+x0A3wyAZxMD7O0d8FLAYyKGYD+BlKuQKfJKZj72/5nd3ZBCFsRms9+HuLd/BN/49R9zJXUz3XjdV+pnADzFzEREKgcAImJmlkR0AMCdE3I2s2Ls6R2AqyccXeTvXzycymA0kx2PmBLSPxFwaGAYL3b3IWTKgoVuyu+XvO+F3bj+zgdzDTUzuH7whZ8F9D+WFiaOW4/xXhmya97rrkP9uXTwROcr5SoMprJlub/ANG/Z043e4ZTvoxRuKK1RGbFx25868a27HvTrIKblEwTe/wiAjonKLcZ45cr3DB8E8HTw++UHgIeA7oERb3FlwnNLIqSyLnoGhspiAgKAPr5jHxQXx3nSmlEZCeOWRztxze0PIOubwuDchjzoHwDuJKJXmFkQkZ6KAQQROQBunA2OIPsTmspmcWBw1AsBJwGI0hqHgqqgEiMg2NnU6/+TRavo0VqjKhJGxxMv4qM/vgOdu/fnzm0IIofcQR5j/vQROX5vXPZsCgBonwV+DmDfGM+xbDEAABwaHMHhUZ9ej5Iwg0HY2ztQBvr37mVHTy929w3CLsIWexPNQVUkhOe6+vCRn9yNr/3yD+jc3Q1oDSnoyEEeR/6U8GT4MIAHxzp/wTAmaFPgDPYz8/cBfKWcAAiK1w4MjGAk4yJkmZNOMIFwwGeAUkaC7N/gY9v2IpV1YZvmcVc2CwGCiOW10P3qyW34zZadWNlYg7ULG7CqaQ4W1FUhHjIRtm0opSirNMK2fV11NKSZWU4068bkwGbyzcDHANSPkUXpQ0ACuvuH4CiFCFlHTTAzYEhC1+GhXNl4yehfELTWeHjbbpiGLFl7V8A8lRGvl2JLVx+e3HMQAkDEMmAZAmHLUmRaMj0y/Jff/e6W/8Yk2j+pp0/k7xRPdBDAt3zBlzUk3Ns36Pct8KSJIlNKdB0eRv9w6fyAYI/gnT19fvhX+sZWpT07H7EMVEVsxCM2SAhkNdA3kqaBVBauoq9i82Y30TH50bHG1M/HBOAGAB8G0OyDoKShYaDM+w4PTUntHgMIHB5NYU9vP6rjUd8roJKw0+YXXsZIxkVV1C7bzibesT5jTSKrUCQiOZv+431f3PjrTeoVkRxzVuAxGWACCwwA+DIwhfqVwMPWWqN78OhFoImfSzsKnXsOlIwBpCBkXRf3d77iF3/MmpwZM4i0Usq26PNExNi0aeo5PjawWAD4CYBH/WSCKt1TeDM6nM7gwMCIVwd4DHdRCIFn9/aMyx0UTeN8aT+1cx+2HziMUJG9/2nOmzZDEQHt/PSeT298OJFol8kxcX/eAPBZIHAcPglvHbnkuZbDwykMprK58winEohtGni+qxeDo2mvkqaotsl7ueeZbV56evZsaaeFNIR2MgfjRuhqMNPq1Z3HnApxnCyc8sPCx3x/QJbKIQzuen//oLfHLU3d/Bn023f1D+PJl7vGaWkxmCloUH14215EQ9as2dWMmVlaNkmtPn/HZy7vSnR0iGQyqWcMgAmmoA1eLXlJQBAoe8/ASF5HzhEYGoT7t75c1HxAIOs7//I8ekcyMGbJjpbMrMxwRKpM6u7ff+H9NyUS4w+JnjEAxpiCIT8icH2lKwns9/UN5iVNpRlRy8TDL+3Gvt7+onTaMhhCEIZSadz97I5cQmb2UH/2UH1MfATAcal/Ogww1hQ85EcFRXcIA5nvHxj2GyyO/zyGJBwezeLup14ap62Fc/4883/Xky9gd++Qn/qdBdoPaGGaZGjnox1XXbk7kWg/LvVPCwBjTIEE8FUAv/FzCKp4APA0uGeKVcCp4uGwbeCuZ7YfcQYLJCHP9ntRScdjzyNkGdCsZ4Hw2TXDMYMzqf+49wsf7NjQ1mZ0dLTmLRcxDYGMpf0rAbxcLH8gWAUcyWRwKLfGznl9zzYM7OkbxH8++FRBy6q97WsI7Y9uwSu9A37oV267r5VhRwxkRv64fkX800i0y83JTdNSSjFNrdR+gugAgEsBDBcnSeRdrncohYHRNCSJvCdbaY142MbPHtuKF/f2eAWVJygp7e+kuutAH/7zkS2IhW1orcssfNbSDEm4zi7KDl+WbG3NYnUnY5ot/tNO7Y7xBx4HsBFH1gq4kAwAAPsPD2LEP/NuuhnErGZ8/Y4HMZrOgDBzEAR1eMyMa+98CEMZ129NKyvtayENAWAwJvnvfp/8WFci0S6Rp90/IQCMAYFBRL8A8M9jTAEXTv+9OsDpnDo+VmOjlonOrl587fYH/B1Jpw8ChleIIQXh2/c8gkd37ke8/HG/JiFBRC7Sqcvu+MyVTyTa2+V07P4JA8AHgeuD4PoJkUHBZueVQ/1+ODD9S3q1dCH8tnMXkr+4D9ls1m8wyW93Ua05V3b+Xw89jZ8++hwqw97Jp+XkfRBBGoYw2Nl4f/JDd29ou9/IJ96fMnI6wVsKzEEbM9sAPuODQOAE6geEn/bd3Ts4aRnYtEAQtnHHU9vQ3T+Mz158DhbOqcmxRFDlQBPonoi8liyt8Z3f/Qm3PLwFsZBV3nw/M0MIlqYtTM7+42+v/sBtG9ruNzYnzzuhvjgqwH2R7xgqZv4GgM+eCAiCypPhVBpXfPeXODiSginkCfWsSyEwnM6iMmzh0jNW4+LTV6HOP/dvqvH0zr344QNP4rGd+1ERtkt+5NtEm08kSBommXD/8beffd+NG9rajM3J5Ak3RVKBwDkWBF8CkBwTHk7LzARbyG7d041/uPlOGEIWZOKlIDiKMZLJorEigrOWNOGs5QuwsK4KVdEINDP6hkbwwr6D+OOLr+Dxnd1wmBGzrbLSPrPn8BHBtdnd+JsCaX6hTEAuR8DM2jcHX2bmwwD+wweYwphGhLwiAPL22RvNuqiKmAURgNLeMfBVkRAG0w5uf2o7fv30DkRMkdumdiSdQcpREIIQtS1YvhkpZ5wvrZAEeIAy2ct+0/aBezzNP69g7dBGoS7kJ4oCn+DbzLwbwC0AKuGtH0zrtzr3HvC9fy4glXoCNSShMmL7Xj5jKOPtMGAYBir9BI8uI+UHGT4jFDWgnZ0V0Jfd3vaBxwup+SccBeQRIv4awJsBbMWRtPFx51QKguu6eLHrEEwpi7LY4m0wybklY4PIW25mzrfZoqhhHgPaDMcNcrN/EKmBc27/7PseL7TmFw0AE0LEJwGsB/AL3wwEJmFKRzeI/3cfHvL32SuFts2OTlhmrUhKYVi24Mzo/2mtTV/w++THuhLt7bIQDl9RTcAUIJBE1AsgwcyfBPB1AKGpogTNgCRvl43BdBZVkdDsOUKuyJ4eA9oIRyVcp1s62Y/f+4WNHX8A0NbWNmVB56xlgAnmgPx+tOsBnAPgT1OxQZDxe/TFXRAk8Fcgel/rDTJDEUmue3uVkT3z3i9s7EB7uwRAyRmkd2cFA0xwDoOOoyeYeYOfMPosgEgQLjKzEEToGxrBln0HEbKM3IHNr1GlV0QkzHBMaifbJXT6S/d+buOPACDRnl81z6sCABPYQBBRFsBXmPlX8GoLLvHDNGVIokdf2i16BlOojNivSfpnsCYARigstetquNmbIlon7/r8xn1oaxMAUCrhlxQAPgj0mKTRcwDexcx/A+BqQ4p1APDbZ7cr4dGGeI0JXgEgwwp5tk25vw8bYtM9n37Pw6XW+oJnAmdIgcHuJPrul16yL1y27IoX9h+66n/fdm8Law3tZDQzmIgEZtGeRTPw7jQBQtphr1hdq4dN8LW//dyVv4YneYn2hAZRWehuFuwBwDLXtLjuw5G3Js6+zNX8UZLG60AElcmAwS55jCBeFVIHMxgshJTSDkE7WRDrP5Cgb/3+c1fe4SGBKZHoEDNdxn3NAMAHAQEQgkixF/oYj8WWXJjJ6g8z8FZph2ztONBOlhnQ5IULs2k3s5zQiUhK0wZJCZ3N9INwpy1x028+c2WwO2fZ6H7WAmDMNFKio0OMnZyLrvmvllHttiqt/paEbBGmBa1caCcLZla+GSk1IILIxjtqTwgpDAtCSriZFBPRY1KI9kpD/PKX//qeXf5XKNHeITpaWwtaPfXaAsCY+0q0t4uOzk4Oypza2tutJ3Zk3phhfrvL6gJmtBh2WDAztOuAlesBgoj9XngCc7AdKc1Y0F6BQE7YXv2AkMIwIAwTAMPNpLKCxJNS0D2mwN2/+cyVTwQSTiTaJQCUm+pfbQDIjba2NvEAIMamQu+//37j+j/tXpMiOkdpvUFrvY5BCww77AmcNbRSYKXArIMcMyO3yfykGWY68g//YE0ikBAgYUBICRCBtYKbybiCsEMQPQ6IzRGoh++6euMLY6+5oa3N2AxoFDmR85oHwDhWSLQLJI6Ok9//bzfFe7R1Ugp6jcFY67BYDubFinUTEeKChA3DOCLaKRnYL/ZkDVYuwJxi5kEpxR6t6RXboK1ZpTvDkrb8r3D9zk984u0ZTBD6uYBOznKhv1oBMO6+29ra6AFAbN7awpiEXttuvjn04LZ07dy51Q19g6kFw1rXRuxQJWlVC+YKBocVYICIDWYHJEYFYTAL2ZtOpQdrotaBWMjeve/QgYMPnNtyiM47eiUu0d4uD3R20qtN6GPH/wfzTUBtWJwleQAAAABJRU5ErkJggg==" alt="merabti.com"></a>
  <h1>مشاركة الملفات</h1>
  <p>شبكة محلية بين الحاسوب والهاتف</p>
</header>
<main>
  <div class="card">
    <h2>إرسال ملفات إلى الحاسوب</h2>
    <label class="btn" for="pick">اختر الملفات</label>
    <input type="file" id="pick" multiple>
    <div class="bar" id="bar"><div id="fill"></div></div>
    <div id="status"></div>
  </div>
  <div class="card">
    <div class="row">
      <h2>ملفات الحاسوب</h2>
      <button class="btn light small" onclick="load()">تحديث</button>
    </div>
    <ul id="list"></ul>
  </div>
</main>
<footer><a href="https://merabti.com" target="_blank" rel="noopener">merabti.com</a></footer>
<script>
function fmt(b){
  if(b<1024) return b+' B';
  if(b<1048576) return (b/1024).toFixed(1)+' KB';
  if(b<1073741824) return (b/1048576).toFixed(1)+' MB';
  return (b/1073741824).toFixed(2)+' GB';
}
async function load(){
  const ul=document.getElementById('list');
  try{
    const r=await fetch('/list',{cache:'no-store'});
    const files=await r.json();
    ul.innerHTML='';
    if(!files.length){ul.innerHTML='<li class="empty">لا توجد ملفات بعد</li>';return;}
    files.forEach(f=>{
      const li=document.createElement('li');
      const box=document.createElement('div');box.className='name';
      const n=document.createElement('div');n.textContent=f.name;
      const s=document.createElement('div');s.className='size';s.textContent=fmt(f.size);
      box.append(n,s);
      const a=document.createElement('a');a.textContent='تحميل';
      a.href='/file?name='+encodeURIComponent(f.name);
      li.append(box,a);ul.append(li);
    });
  }catch(e){ul.innerHTML='<li class="empty">تعذر الاتصال بالحاسوب</li>';}
}
function sendOne(file,i,total){
  return new Promise((ok,fail)=>{
    const x=new XMLHttpRequest();
    x.open('POST','/upload?name='+encodeURIComponent(file.name));
    x.upload.onprogress=e=>{
      if(e.lengthComputable){
        document.getElementById('fill').style.width=(e.loaded/e.total*100)+'%';
      }
    };
    x.onload=()=>x.status==200?ok():fail();
    x.onerror=fail;
    document.getElementById('status').textContent='جاري الإرسال '+(i+1)+' من '+total+': '+file.name;
    x.send(file);
  });
}
document.getElementById('pick').addEventListener('change',async e=>{
  const files=[...e.target.files];if(!files.length) return;
  const bar=document.getElementById('bar'),st=document.getElementById('status');
  bar.style.display='block';
  try{
    for(let i=0;i<files.length;i++){
      document.getElementById('fill').style.width='0';
      await sendOne(files[i],i,files.length);
    }
    st.textContent='تم إرسال '+files.length+' ملف بنجاح ✔';
  }catch(err){st.textContent='حدث خطأ أثناء الإرسال';}
  e.target.value='';
  setTimeout(()=>{bar.style.display='none';},1500);
  load();
});
load();
</script>
</body>
</html>
'@

# --- Start the server ---
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:$Port/")
try {
    $listener.Start()
} catch {
    Write-Host "Could not start the server on port $Port. Is it already running?" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

$ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
       Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
       Select-Object -ExpandProperty IPAddress

Clear-Host
Write-Host ""
Write-Host "  LOCAL FILE SERVER IS RUNNING" -ForegroundColor Green
Write-Host ""
Write-Host "  Shared folder: $Root"
Write-Host ""
Write-Host "  Type this address in the phone browser:" -ForegroundColor Yellow
foreach ($ip in $ips) { Write-Host "     http://$($ip):$Port" -ForegroundColor Cyan }
Write-Host ""
Write-Host "  Close this window to stop the server."
Write-Host ""

Start-Process explorer.exe $Root

while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $res = $ctx.Response
    try {
        $path = $req.Url.AbsolutePath
        $method = $req.HttpMethod

        if ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) {
            Send-Text $res $Html 'text/html; charset=utf-8'
        }
        elseif ($method -eq 'GET' -and $path -eq '/list') {
            $items = @(Get-ChildItem -LiteralPath $Root -File | Sort-Object LastWriteTime -Descending | ForEach-Object {
                [pscustomobject]@{ name = $_.Name; size = $_.Length }
            })
            $json = if ($items.Count -eq 0) { '[]' } else { ConvertTo-Json -InputObject $items -Compress }
            $res.AddHeader('Cache-Control', 'no-store')
            Send-Text $res $json 'application/json; charset=utf-8'
        }
        elseif ($method -eq 'GET' -and $path -eq '/file') {
            $name = Get-SafeName (Get-Query $req 'name')
            $file = if ($name) { Join-Path $Root $name } else { $null }
            if ($file -and (Test-Path -LiteralPath $file -PathType Leaf)) {
                $fs = [IO.File]::OpenRead($file)
                try {
                    $res.ContentType = 'application/octet-stream'
                    $res.ContentLength64 = $fs.Length
                    $res.AddHeader('Content-Disposition', "attachment; filename=`"download`"; filename*=UTF-8''" + [Uri]::EscapeDataString($name))
                    $fs.CopyTo($res.OutputStream)
                } finally { $fs.Close() }
                Write-Host "  Sent to phone:     $name" -ForegroundColor Cyan
            } else {
                $res.StatusCode = 404
                Send-Text $res 'Not found' 'text/plain'
            }
        }
        elseif ($method -eq 'POST' -and $path -eq '/upload') {
            $name = Get-SafeName (Get-Query $req 'name')
            if (-not $name) {
                $res.StatusCode = 400
                Send-Text $res 'Bad name' 'text/plain'
            } else {
                $dest = Get-FreePath $name
                $out = [IO.File]::Create($dest)
                try { $req.InputStream.CopyTo($out) } finally { $out.Close() }
                Write-Host "  Received from phone: $([IO.Path]::GetFileName($dest))" -ForegroundColor Green
                Send-Text $res 'OK' 'text/plain'
            }
        }
        else {
            $res.StatusCode = 404
            Send-Text $res 'Not found' 'text/plain'
        }
    } catch {
        try { $res.StatusCode = 500 } catch {}
    } finally {
        try { $res.Close() } catch {}
    }
}
